# OTT Thumbnail Extractor - Web + Telegram

See README in previous chat for deploy steps.
